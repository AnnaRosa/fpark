// BASIC
import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { ParkerApp } from './app.component';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { IonicStorageModule } from '@ionic/storage';

// PAGES
import { OverviewPage } from '../pages/overview/overview';
import { AccountPage } from '../pages/account/account';
import { StatisticsPage } from '../pages/statistics/statistics';
import { TabsPage } from '../pages/tabs/tabs';
import { TutorialPage } from '../pages/tutorial/tutorial';
import { AccountEditPage } from '../pages/account-edit/account-edit';
import { SocialPage } from '../pages/social/social';
import { LiftPage } from '../pages/lift/lift';
import { CarpoolPage } from '../pages/carpool/carpool';
import { PopoverSettingsPage } from '../pages/popover-settings/popover-settings';
import {LoginPage} from "../pages/login/login";
import {RegisterPage} from "../pages/register/register";

// PIPES

// PROVIDERS
import { LocationTrackerProvider } from '../providers/location-tracker/location-tracker';
import { ParkingProvider } from '../providers/parking/parking';
import { OrientationProvider } from '../providers/orientation/orientation';
import { GamificationProvider } from '../providers/gamification/gamification';
import { PushLocalProvider } from '../providers/push-local/push-local';
import { CameraProvider } from '../providers/camera/camera';
import { FileProvider } from '../providers/file/file';
import { PersistenceProvider } from '../providers/persistence/persistence';
import { SettingsProvider } from '../providers/settings/settings';
import { DataHandlerProvider } from '../providers/data-handler/data-handler';
import { UserProvider } from '../providers/user/user';
import { RouteProvider } from '../providers/routes/routes';
import {URideProvider} from '../providers/URide/uride';

// IONIC NATIVE
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen'
import { Globalization } from '@ionic-native/globalization';
import { BackgroundGeolocation } from '@ionic-native/background-geolocation';
import { Geolocation } from '@ionic-native/geolocation';
import { ScreenOrientation } from '@ionic-native/screen-orientation';
import { HeaderColor } from '@ionic-native/header-color';
import { LocalNotifications } from '@ionic-native/local-notifications';
import { Camera } from '@ionic-native/camera';
import { Base64ToGallery } from '@ionic-native/base64-to-gallery';
import { File } from '@ionic-native/file';
import { FilePath } from '@ionic-native/file-path';
import { Crop } from '@ionic-native/crop';
import { BackgroundMode } from '@ionic-native/background-mode';
import { TextToSpeech } from '@ionic-native/text-to-speech';
import { Toast } from '@ionic-native/toast';

export function createTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}

@NgModule({
  declarations: [
    ParkerApp,
    OverviewPage,
    AccountPage,
    StatisticsPage,
    TabsPage,
    TutorialPage,
    SocialPage,
    AccountEditPage,
    LiftPage,
    CarpoolPage,
    PopoverSettingsPage,
    LoginPage,
    RegisterPage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(ParkerApp),
    HttpClientModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: (createTranslateLoader),
        deps: [HttpClient]
      }
    }),
    TranslateModule,
    IonicStorageModule.forRoot()
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    ParkerApp,
    OverviewPage,
    AccountPage,
    StatisticsPage,
    TabsPage,
    TutorialPage,
    SocialPage,
    AccountEditPage,
    LiftPage,
    CarpoolPage,
    PopoverSettingsPage,
    LoginPage,
    RegisterPage
  ],
  providers: [
    LocationTrackerProvider,
    StatusBar,
    SplashScreen,
    Globalization,
    BackgroundGeolocation,
    Geolocation,
    ScreenOrientation,
    HeaderColor,
    LocalNotifications,
    Camera,
    Base64ToGallery,
    File,
    FilePath,
    Crop,
    BackgroundMode,
    TextToSpeech,
    Toast,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    LocationTrackerProvider,
    ParkingProvider,
    OrientationProvider,
    GamificationProvider,
    PushLocalProvider,
    CameraProvider,
    FileProvider,
    PersistenceProvider,
    DataHandlerProvider,
    SettingsProvider,
    UserProvider,
    RouteProvider,
    URideProvider
  ]
})
export class AppModule {}
