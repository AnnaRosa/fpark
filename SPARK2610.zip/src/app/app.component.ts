import { Component } from '@angular/core';
import { Platform } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { TabsPage } from '../pages/tabs/tabs';
import { TutorialPage } from "../pages/tutorial/tutorial";

import { TranslateService } from "@ngx-translate/core";
import { Globalization } from "@ionic-native/globalization";
import { HeaderColor } from "@ionic-native/header-color";
import {BackgroundMode} from "@ionic-native/background-mode";
import {PersistenceProvider} from "../providers/persistence/persistence";

@Component({
  templateUrl: 'app.html'
})
export class ParkerApp {
    rootPage:any = TabsPage;

    constructor(platform: Platform, statusBar: StatusBar, splashScreen: SplashScreen, public backgroundMode: BackgroundMode,
              translate: TranslateService, globalization: Globalization, private persistenceProvider: PersistenceProvider, private headerColor: HeaderColor) {

        this.headerColor.tint('#7cb342');

        // Hole aktuelle Sprache vom Gerät
        translate.setDefaultLang('de');
        translate.use('de');
        // translate.addLangs(['en']);

        // Wurde Tutorial bereits angeschaut?
        this.persistenceProvider.getFromStorage('tutorialShown').then((result) => {
            if (result) {
                this.rootPage = TabsPage;
            } else {
                this.rootPage = TutorialPage;
            }
        });


        // Sobald Gerät initialisiert ist
        platform.ready().then(() => {
          statusBar.styleLightContent();
          splashScreen.hide();

          // App im Hintergrund aktiv halten
          // this.backgroundMode.enable();
        });
    }
}
