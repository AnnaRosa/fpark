import {Component, OnInit} from '@angular/core';

import { OverviewPage } from '../overview/overview';
import { AccountPage } from '../account/account';
import { StatisticsPage } from '../statistics/statistics';

import { TranslateService } from "@ngx-translate/core";
import { SocialPage } from "../social/social";

@Component({
  templateUrl: 'tabs.html'
})
export class TabsPage implements OnInit {

  tabOverview = OverviewPage;
  tabStats = StatisticsPage;
  tabSocial = SocialPage;
  tabAccount = AccountPage;

  tabs: object[];

  constructor(public translate: TranslateService) { }

  ngOnInit() {
    this.translate.stream(['OVERVIEW', 'STATS', 'SOCIAL', 'ME']).subscribe((res: object) => {
      this.tabs = [
        { root: this.tabOverview, title: res['OVERVIEW'], icon: 'map' },
        { root: this.tabStats, title: res['STATS'], icon: 'stats' },
        { root: this.tabSocial, title: res['SOCIAL'], icon: 'people' },
        { root: this.tabAccount, title: res['ME'], icon: 'person' },
      ];
      console.table(this.tabs);
    });
  }
}
