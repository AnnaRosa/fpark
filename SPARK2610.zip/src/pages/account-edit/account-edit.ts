import { Component } from '@angular/core';
import {FabContainer, IonicPage, NavParams, ViewController} from 'ionic-angular';
import { CameraProvider } from "../../providers/camera/camera";
import {PersistenceProvider} from "../../providers/persistence/persistence";

@IonicPage()
@Component({
  selector: 'page-account-edit',
  templateUrl: 'account-edit.html',
})
export class AccountEditPage {
  userObject: object = this.navParams.get('user');
  userName: string;
  userMotto: string;
  userMail: string;
  userPlace: string;
  userPlate: string;
  userPrivacy: boolean;

  profileImgUri: string = this.persistenceProvider.getProfileImageUri();

  valuesChanged: boolean = false;

  constructor(public viewCtrl: ViewController, private navParams: NavParams, public cameraProvider: CameraProvider,
              private persistenceProvider: PersistenceProvider) {
    this.userName = this.userObject['name'];
    this.userMotto = this.userObject['motto'];
    this.userMail = this.userObject['mail'];
    this.userPlace = this.userObject['residence'];
    this.userPlate = this.userObject['plate'];
    this.userPrivacy = this.userObject['privateAccount'];
  }

  changeProfilePicture(mode: string, fab: FabContainer) {
    switch(mode) {
      case 'storage':
        // Hole Bild von Gerät
        this.cameraProvider.getImage('PHOTOLIBRARY').then((uri: string) => {
          // Schneide Bild zu
          this.cameraProvider.cropImage(uri).then((croppedUri: string) => {
            // Setze neues Bild
            this.profileImgUri = croppedUri;
            this.persistenceProvider.setProfileImageUri(croppedUri);
          }, (cropErr) => console.log(cropErr));
        }, (err) => console.log(err));
        break;
      case 'camera':
        // Hole Bild von Kamera
        this.cameraProvider.getImage('CAMERA').then((uri: string) => {
          // Schneide Bild zu
          this.cameraProvider.cropImage(uri).then((croppedUri: string) => {
            // Setze neues Bild
            this.profileImgUri = croppedUri;
            this.persistenceProvider.setProfileImageUri(croppedUri);
          }, (cropErr) => console.log(cropErr));
        }, (err) => console.log(err));
        break;
    }
    fab.close();
  }

  ionViewDidLoad() { }

}
