import { Component } from '@angular/core';
import {IonicPage, NavController, NavParams, ModalController, Modal} from 'ionic-angular';
import { OrientationProvider } from "../../providers/orientation/orientation";
import { GamificationProvider } from "../../providers/gamification/gamification";
import {AccountEditPage} from "../account-edit/account-edit";
import {PersistenceProvider} from "../../providers/persistence/persistence";
import {SettingsProvider} from "../../providers/settings/settings";
import {UserProvider} from "../../providers/user/user";
import {LoginPage} from "../login/login";
import {RegisterPage} from "../register/register";

@IonicPage()
@Component({
  selector: 'page-account',
  templateUrl: 'account.html',
})
export class AccountPage {
  profileImgUri: string = this.persistenceProvider.getProfileImageUri();
  profileImgSubscription: any;

  orientationSubscription: any;
  curOrientation: string = this.orientationProvider.getScreenOrientation();
  private user: object = {
    name: 'Max Mustermann',
    motto: 'Hier ist es toll!',
    mail: 'mail@mail.com',
    residence: 'Stuttgart',
    plate: 'S-KK-1337',
    privateAccount: true,
  };
  userAchievements: object[];

  constructor(public navCtrl: NavController, public navParams: NavParams, public orientationProvider: OrientationProvider,
              public gamification: GamificationProvider, public modalCtrl: ModalController,
              private persistenceProvider: PersistenceProvider, public settingsProvider: SettingsProvider,
              public userProvider: UserProvider) {
    // Höre auf neue Messages von OrientationChanged
    this.orientationSubscription = this.orientationProvider.screenOrientationChanged.subscribe((o) => {
      this.curOrientation = o;
    });
    // Höre auf neue Messages von ProfileImageChanged
    this.profileImgSubscription = this.persistenceProvider.profileImageChanged.subscribe((newImageUri) => {
      this.profileImgUri = newImageUri;
    });
  }

  ionViewDidLoad() {
    this.userAchievements = this.gamification.getAchievements();
  }

  editAccount() {
    let editModal = this.modalCtrl.create(AccountEditPage, { user: this.user });

    editModal.onDidDismiss((newObject) => {
      if(newObject)
        this.user = newObject;
    });

    editModal.present();
  }

  // both modal methods for auth
  openLogin() {
      const loginModal = this.modalCtrl.create(LoginPage);
      loginModal.present().then(data => {
          console.log(data);
      }).catch(err => {
          console.log(err);
      });
  }
  openRegistration() {
      const regModal = this.modalCtrl.create(RegisterPage);
      regModal.present().then(data => {
          console.log(data);
      }).catch(err => {
          console.log(err);
      });
  }
}
