import { Component } from '@angular/core';
import {IonicPage, LoadingController, NavParams, ToastController, ViewController} from 'ionic-angular';
import {UserProvider} from "../../providers/user/user";
import { Toast } from '@ionic-native/toast';

/**
 * Generated class for the RegisterPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-register',
  templateUrl: 'register.html',
})
export class RegisterPage {

    userName: string;
    password: string;
    eMail: string;
    fullName: string;
    aboutMe: string;
    residence: string;
    numberPlate: string;
    accPrivate: string;

    constructor(public viewCtrl: ViewController, public navParams: NavParams, public userProvider: UserProvider,
                public toast: Toast, public loadingCtrl: LoadingController) {

    }

    /**
     * tries to register a new user
     */
    register() {
        if (this.userName && this.password && this.eMail) {
            const loading = this.loadingCtrl.create({
                content: 'Registrieren...'
            });
            loading.present();

            this.userProvider.register({
                username: this.userName,
                password: this.password,
                fullname: this.fullName,
                residence: this.residence,
                email: this.eMail,
                aboutMe: this.aboutMe,
                numberPlate: this.numberPlate,
                isPrivate: this.accPrivate,
            }).subscribe(data => {
                this.toast.show(data.msg, '3000', 'bottom').subscribe(() => {
                    if (data.msg === 'registration successful') {
                        this.viewCtrl.dismiss();
                    }
                });
                loading.dismiss();
            }, err => {
                console.log(err);
                loading.dismiss();
            });
        }
    }

}
