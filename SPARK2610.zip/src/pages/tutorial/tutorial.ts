import {Component, ViewChild} from '@angular/core';
import {IonicPage, NavController, NavParams, Slides} from 'ionic-angular';
import { TabsPage } from "../tabs/tabs";
import { Storage } from "@ionic/storage";
import {PersistenceProvider} from "../../providers/persistence/persistence";

/**
 * Generated class for the TutorialPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-tutorial',
  templateUrl: 'tutorial.html',
})
export class TutorialPage {
  @ViewChild(Slides) slides: Slides;

  constructor(public navCtrl: NavController, public navParams: NavParams, private persistenceProvider: PersistenceProvider) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad TutorialPage');
  }

  startApp() {
    this.persistenceProvider.writeToStorage('tutorialShown', true);
    this.navCtrl.setRoot(TabsPage);
  }

  nextSlide() {
    this.slides.slideTo(this.slides.getActiveIndex() + 1, 300);
  }
  previousSlide() {
    this.slides.slideTo(this.slides.getActiveIndex() -1, 300);
  }

}
