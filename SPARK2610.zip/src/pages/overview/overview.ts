import {Component, OnInit} from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { LocationTrackerProvider } from "../../providers/location-tracker/location-tracker";
import { ParkingProvider } from "../../providers/parking/parking";
import { OrientationProvider } from "../../providers/orientation/orientation";
import { HttpClient } from '@angular/common/http';
import 'rxjs/add/operator/map';
import { LocalNotifications } from "@ionic-native/local-notifications";

declare const L: any;

import "leaflet";
import "leaflet-tilelayer-mbtiles-ts";
import {SettingsProvider} from "../../providers/settings/settings";
import {Observable} from "rxjs/Rx";

@IonicPage()
@Component({
  selector: 'page-overview',
  templateUrl: 'overview.html',
})
export class OverviewPage implements OnInit {
  Math: any;

  static map: any;
  static mapLoaded: boolean = false;
  trackedMarker: any;

  updateLoopStarted = false;
  currentLocation = {lat: 0, lng: 0};

  distToLocation: number = 0;
  isTracking: boolean = false;
  orientationSubscription: any;
  curOrientation: string = this.orientationProvider.getScreenOrientation();

  constructor(public navCtrl: NavController, public navParams: NavParams, public orientationProvider: OrientationProvider,
              public locationTracker: LocationTrackerProvider, public parking: ParkingProvider, public http: HttpClient,
              private localNotification: LocalNotifications, public settingsProvider: SettingsProvider) {
    if (! this.updateLoopStarted) {
      this.updateLoopStarted = true;
      Observable.interval(20000).subscribe(x => { parking.runParkingLotUpdateRoutine(); });
      Observable.interval(3000).subscribe(x => { parking.checkNearestParkingLot(this.isTracking, this.currentLocation); });
    }
  }
  ngOnDestroy() {
    //prevent memory leak when component destroyed
    this.orientationSubscription.unsubscribe();
  }

  /**
   * Load map on Angular lifecycle hook
   */
  ngOnInit() {
    // Math auf Bindings verfügbar machen
    this.Math = Math;
    this.orientationSubscription = this.orientationProvider.screenOrientationChanged.subscribe((o) => {
      this.curOrientation = o;
    });
    this.loadMap();
  }

  /**
   * Getter for map loaded
   */
  isMapLoadedInverted() {
    return !OverviewPage.mapLoaded;
  }

  /**
   * Starte das GeoTracking (Foreground & Background)
   */
  startTracking() {
    this.locationTracker.startTracking();
    this.currentLocation = {lat: this.locationTracker.lat, lng: this.locationTracker.lng};
    this.trackedMarker = L.circle([this.locationTracker.lat,this.locationTracker.lng],{fillColor: '#8bc34a',weight:1,color: '#6da529',fillOpacity: 0.5, radius: 2}).addTo(OverviewPage.map);
    this.locationTracker.distChanged.subscribe((d: number) => {
      this.currentLocation = {lat: this.locationTracker.lat, lng: this.locationTracker.lng};
      this.distToLocation = this.parking.distanceToParkingLog(this.currentLocation);
      this.trackedMarker.setLatLng([this.locationTracker.lat,this.locationTracker.lng]);
    });
  }

  /**
   * Stop GeoTracking
   */
  stopTracking() {
    this.locationTracker.stopTracking();
    this.trackedMarker.remove();
  }

  /**
   * Toggle GeoTracking
   */
  toggleTracking() {
    if(this.isTracking) {
      this.stopTracking();
      this.distToLocation = 0;
      this.currentLocation = {lat: 48.4803986, lng: 9.1882144};
      this.parking.removeHighlight();
    } else {
      this.startTracking();
      this.parking.checkNearestParkingLot(true, this.currentLocation);
    }
    this.isTracking = !this.isTracking;
  }

  /**
   * Set view to current position
   */
  focusCurrentPosition() {
    OverviewPage.map.panTo([this.locationTracker.lat,this.locationTracker.lng]);
    OverviewPage.map.setZoom(19);
  }

  focusHighlightedParkingLot() {
    OverviewPage.map.panTo([this.parking.getParkingLotCoordinates().lat,this.parking.getParkingLotCoordinates().lng]);
    OverviewPage.map.setZoom(19);
  }

  /**
   * Lade Offline Map
   */
  loadMap() {
    OverviewPage.map = new L.Map('map',{ zoomControl:false }).setView([48.480012, 9.186682], 17);
    //let mb = L.tileLayer.mbTiles('assets/geo-data/map.mbtiles', { //Old: with mbtiles
    L.tileLayer('assets/geo-data/tiles/{z}/{x}/{y}.png', {
      minZoom: 16,
      maxZoom: 19,
      attribution: 'Map data &copy; 2012 OpenStreetMap contributors'
    }).addTo(OverviewPage.map);
    let bounds = L.latLngBounds(L.latLng(48.477139, 9.182976), L.latLng(48.484793, 9.191614));
    OverviewPage.map.setMaxBounds(bounds);
    OverviewPage.map.on('drag', function() {
      //OverviewPage.map.panInsideBounds(bounds, { animate: false });
    });
    OverviewPage.mapLoaded = true;
  }
}

