import { Component } from '@angular/core';
import {IonicPage, App, NavController, ViewController} from 'ionic-angular';
import {TutorialPage} from "../tutorial/tutorial";
import {SettingsProvider} from "../../providers/settings/settings";
import {PersistenceProvider} from "../../providers/persistence/persistence";
import {TranslateService} from "@ngx-translate/core";

/**
 * Generated class for the PopoverSettingsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-popover-settings',
  templateUrl: 'popover-settings.html',
})
export class PopoverSettingsPage {

  constructor(public viewCtrl: ViewController, public appCtrl: App, public translateService: TranslateService) {
  }

  close() {
    this.viewCtrl.dismiss();
  }

  showTutorial() {
    // TODO: evtl Stack Overflow möglich?
    this.appCtrl.getRootNav().push(TutorialPage);
    this.close();
  }

  /*
  toggleLang() {
      this.translateService.use('en');
  }
  */
}
