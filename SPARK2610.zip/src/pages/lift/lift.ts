import { Component } from '@angular/core';
import {IonicPage, NavParams, ViewController} from 'ionic-angular';
import { Geolocation } from '@ionic-native/geolocation';
import { HttpClient } from '@angular/common/http';
import { UserProvider } from '../../providers/user/user';
import {RouteProvider} from '../../providers/routes/routes'
import { URideProvider } from '../../providers/URide/uride';
import * as moment from 'moment';
import { TranslateService } from "@ngx-translate/core";

@IonicPage()
@Component({
  selector: 'page-lift',
  templateUrl: 'lift.html',
})
export class LiftPage {

  offer: boolean = this.navParams.get('offer');
  open: boolean = this.navParams.get('open');
  isRegularRide: boolean;
  location: string;
  address: any;
  addressInput: string;
  addressName: string;
  freeSeats: number;
  liftTime: any;
  regularRideStartDate: any;
  regularRideEndDate: any;
  regularRideTime: any;
  toUniversity: any;
  rides:any; 
  currentYear: number;
  addressSuggestion: any; 
  locationLatitude: any;
  locationLongitude: any;
  userRoutes: any; 
  inputroutetype: string; 
  selectedRoute: number;
  weekdays: any[];

  
  constructor(public viewCtrl: ViewController, public navParams: NavParams, public geolocation: Geolocation, 
    public routeProvider: RouteProvider, public userProvider: UserProvider, public uRideProvider: URideProvider,
    public translate: TranslateService,
    public http: HttpClient) {
    this.isRegularRide = false;
    this.toUniversity = true;
    this.inputroutetype = "existingroutes";
    this.currentYear = new Date().getFullYear();
    this.weekdays = [];
    this.translate.stream(['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY','FRIDAY','SATURDAY','SUNDAY']).subscribe((res: object) => {
      
      this.weekdays = [
        { day: res['MONDAY'], value: false, dayVal:'Monday' },
        { day: res['TUESDAY'], value: false, dayVal:'Tuesday' },
        { day: res['WEDNESDAY'], value: false, dayVal:'Wednesday' },
        { day: res['THURSDAY'], value: false, dayVal:'Thursday' },
        { day: res['FRIDAY'], value: false, dayVal:'Friday' },
        { day: res['SATURDAY'], value: false, dayVal:'Saturday' },
        { day: res['SUNDAY'], value: false, dayVal:'Sunday' }
       
      ];
    });
    

    }

  ionViewDidLoad( ) { 
    this.uRideProvider.getUserRoutes(this.userProvider.getUserId()).subscribe(
      res=>{
        this.userRoutes = res.body;
      }
    );
  }

  routeInputChange(inputType:string){
    this.inputroutetype = inputType;
  }
 
  locate(){
    this.geolocation.getCurrentPosition().then((resp) => {
      this.locationLatitude = resp.coords.latitude;
      this.locationLongitude = resp.coords.longitude;
      this.loadAdress(this.locationLatitude, this.locationLongitude);
     }).catch((error) => {
       console.log('Error getting location', error);
     });
  }

  selectRoute(routeId:number){
    this.selectedRoute=routeId;
    this.createDatesFromStartEndDate();
  }

  loadAdress(lat: number, long: number){

     let loc = lat+','+long;
     this.location= loc;
     this.routeProvider.getAddressFromCoordinates(loc).subscribe(res => {
      let adr = res.Response.View[0].Result[0].Location.Address;
      this.setAddress(adr);
      this.address=adr;
        });
  };

  getAddress(){
    this.routeProvider.getAddressFromIncompleteAddress(this.address).subscribe(res => {
    })
  };

  send(){
    let dates = []
    if(!this.isRegularRide){
      dates.push(moment(this.liftTime).toDate().toISOString());
    }else {
      dates = this.createDatesFromStartEndDate();      
    }
    if(this.inputroutetype == 'newroute'){
      this.getRoute().subscribe(res=>{
        this.sendwithWaypoints( this.getRouteFromResponse(res), dates);
      });
    }else{
      if(this.offer){
        this.uRideProvider.addOfferWithExistingRoute(this.userProvider.getUserId(), dates, this.selectedRoute,this.freeSeats).subscribe(
          res=>{
            this.viewCtrl.dismiss();          });
      }else{
        
          this.uRideProvider.addSearchWithExistingRoute(this.userProvider.getUserId(), dates, this.selectedRoute).subscribe(
            res=>{
              this.viewCtrl.dismiss();            });
          
      }
    }
  }

  createDatesFromStartEndDate(){
    let startDate = moment(this.regularRideStartDate).startOf('day');
    let endDate = moment(this.regularRideEndDate).startOf('day');
    let time= this.regularRideTime;
    let selectedWeekdays = this.weekdays.filter (e=>{
      if(e.value){
        return e;
      }
    }).map(e=>{return e.dayVal;} );

    let dates = [];

    while(startDate.isSameOrBefore(endDate)){
      let startdayOfWeek = moment(startDate).format( 'dddd').toString();
      let startDateFormat= moment(startDate).format('YYYY-MM-DD');
      for(let i = 0; i< selectedWeekdays.length; i++){
        if(startdayOfWeek==selectedWeekdays[i] ){
          dates.push(moment(startDateFormat + ' ' + time).toISOString());    
        }
      }
      startDate=startDate.add(1, 'days').startOf('day'); 
    }
    return dates;
  }

  sendwithWaypoints(waypoints:any, dates: any){
    if(this.offer){
      this.addOffer(waypoints, dates);
     }else{
       this.addSearch(waypoints, dates);
     }  
  }

  addOffer(waypoints: any, dates: any){
    this.uRideProvider.addOffer(this.userProvider.getUserId(), this.toUniversity, dates, 
    this.addressName?this.addressName:this.addressInput, this.address, waypoints,
      this.freeSeats).subscribe(resp => {
      this.viewCtrl.dismiss();
     });
  }

  addSearch(waypoints: any, dates:any ){
    this.uRideProvider.addSearch(this.userProvider.getUserId(), this.toUniversity, dates,
     this.addressName?this.addressName:this.addressInput,
     this.address, waypoints).subscribe(resp => {
      this.viewCtrl.dismiss();

     });
  }

  changeAddress() { 
    this.routeProvider.getAddressFromIncompleteAddress(this.addressInput).subscribe (resp => { 
      this.addressSuggestion = resp.suggestions;
    })
  }



 
  setAddressFromSuggestion(selectedAddress: string){
    this.address=selectedAddress;
    this.routeProvider.getCoordinatesFromAddress(selectedAddress).subscribe(res => {
      let responseAddress = res.Response.View[0].Result[0].Location.Address;
      this.setAddress(responseAddress);
     let displayPos= res.Response.View[0].Result[0].Location.DisplayPosition;
      let long = displayPos.Longitude;
      let lat = displayPos.Latitude;
      this.locationLongitude= long;
      this.locationLatitude = lat; 
      this.location = lat + ','+long;
    });
    this.addressSuggestion= []; 
  }

  getRoute(){ 
    if(this.toUniversity){
        return this.routeProvider.getRouteToUniversity('geo!'+this.location);
    }else{
      return this.routeProvider.getRouteFromUniversity('geo!'+this.location);
    }
  }

  selectDirection(val: boolean){
    this.toUniversity=val;
  }

  getRouteFromResponse(response: any){
    let route = [];
    response.response.route[0].leg[0].maneuver.forEach(element => {
      route.push({latitude: element.position.latitude, 
      longitude: element.position.longitude,
      lengthWP: element.length });
    });
   return route;
    
  }

  setAddress(responseAddress){
    let addr = {
      street: responseAddress.Street,
      number: responseAddress.HouseNumber,
      zipCode: responseAddress.PostalCode,
      city: responseAddress.City,
    }
    this.address= addr;
    let street = addr.street? addr.street +' ':'';
    let num = addr.number? addr.number +' ':'';
    let city = addr.city ? addr.city +' ':''
    let post = addr.zipCode? addr.zipCode +' ':'';
    let outputString = (street + num + city+post).length > 0 ? (street + num + city+post).toString(): 'Keine Adresse gefunden';
    this.addressInput = outputString.toString() ;
  }

  isChecked(){
    return this.toUniversity;  
  }

  isNotChecked(){
    return !this.toUniversity;
  }

  setReg(){
    console.log(typeof this.isRegularRide + typeof this.toUniversity);
  }

}
