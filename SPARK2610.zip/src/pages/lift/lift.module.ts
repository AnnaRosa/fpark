import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { LiftPage } from './lift';

@NgModule({
  declarations: [
    LiftPage,
  ],
  imports: [
    IonicPageModule.forChild(LiftPage),
  ],
})
export class LiftPageModule {}
