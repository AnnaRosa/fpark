import { Component } from '@angular/core';
import { IonicPage, ModalController, NavController, NavParams, FabButton, FabContainer } from 'ionic-angular';
import { LiftPage } from "../lift/lift";
import {SettingsProvider} from "../../providers/settings/settings";
import {UserProvider} from "../../providers/user/user";
import {LoginPage} from "../login/login";
import {RegisterPage} from "../register/register";
import {RouteProvider} from '../../providers/routes/routes'
import { URideProvider } from '../../providers/URide/uride';
import * as moment from 'moment';


/**
 * Generated class for the SocialPage page. This page is used to search for, offer and manage lifts.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-social',
  templateUrl: 'social.html',
})

export class SocialPage {

  carpoolEnabled: boolean = false;
  liftBackground: string = 'assets/imgs/backgrounds/lift4.jpg';
  showOpenLifts: boolean;
  showAccepted: boolean;
  openEntrySearch: string; 
  openEntryOffer: string;
  openOfferRequests: any;
  openSearchRequests: any;
  myRequests: any;
  mySearches: any; 
  mySearchesPast:any;
  myOffers: any;  
  myOffersPast: any;
  selectedPage:string;
  userName: string; 
  amount_open_request: number;
  openrequests: any;

  participationRequestStates: any = 
    {requested: 'requested',
    accepted: 'accepted',
    denied: 'denied',
    canceled: 'canceled',
    quit: 'quit'
    };
  


  constructor(public navCtrl: NavController, public navParams: NavParams, public modalCtrl: ModalController,
              public settingsProvider: SettingsProvider, public userProvider: UserProvider,
              public routeProvider: RouteProvider, public URideProvider: URideProvider ) {
    // Zufälliges Hintergrundbild
    this.liftBackground = 'assets/imgs/backgrounds/lift' + Math.floor((Math.random() * 4) + 1) + '.jpg' ;
    this.selectedPage="mySearch";
    this.loadSearches();
    this.loadOffers();
    this.loadOpenRequests(); 
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SocialPage');
  }
 
  loadOpenRequests(){ 
    this.URideProvider.getOpenRequests(this.userProvider.getUserId()).subscribe(
        res =>{
          this.openrequests = res.body;
          console.log(this.openrequests);
        }
    );
  }

  loadSearches(){
    this.URideProvider.getSearches(this.userProvider.getUserId()).subscribe(
      res=> {this.mySearches = (res.body.searches!=undefined &&res.body.searches.current!=undefined)? res.body.searches.current:[];
        this.mySearchesPast = (res.body.searches!=undefined &&res.body.searches.past!=undefined)? res.body.searches.past:[];
       });
  }

  loadOffers(){
    this.URideProvider.getOffers(this.userProvider.getUserId()).subscribe(
      res=> {this.myOffers = res.body.offers!=undefined&&res.body.offers.current!=undefined? res.body.offers.current: [];
        this.myOffersPast = res.body.offers!=undefined&&res.body.offers.past!=undefined? res.body.offers.past: []; 
        });
  }
  /**
   * Biete Mitfahrgelegenheit an
   */
  offerLift(fab: FabContainer) {
    // Erstelle Modal für das Angebot
    let offerModal = this.modalCtrl.create(LiftPage, {offer: true, finalFunction: this.loadOffers});
    
    offerModal.onDidDismiss((data) => {

    });

    offerModal.present();
  }

  /**
   * Nehme Mitfahrgelegenheit in Anspruch
   */
  searchLift( fab: FabContainer) {
    // Erstelle Modal für die Annahme
    let takeModal = this.modalCtrl.create(LiftPage, {search: true, http: this.userProvider.getHttpClient()});
    fab.close();
    takeModal.onDidDismiss((data) => {
    });

    takeModal.present();
  }

  setOpenSearchEntry(id: string){ 
    if(this.openEntrySearch==id){
      this.openEntrySearch=''; 
    }else{
      this.openEntrySearch=id;
      this.loadSearchMatches(id);
      }
  }  

  setOpenOfferEntry(id: string){ 
    if(this.openEntryOffer==id){
      this.openEntryOffer='';
    }else{
      this.openEntryOffer=id;
      this.loadOfferMatches(id);
      }
  }  

  loadOfferMatches(id: string){
    this.URideProvider.getOfferMatches(id, this.userProvider.getUserId()).subscribe(res => {
      this.myOffers.forEach((element) => {
        if(res&& res.body&&res.body.ID && element.ID == res.body.ID){  
          element.recommendationsSearches = res.body.recommendationsSearches;
          element.recommendationsLifts = res.body.recommendationsLifts;
          element.participationRequests = res.body.participationRequests;
          element.requestedParticipations = res.body.requestedParticipations;
          element.quitParticipations = res.body.quitParticipations;
          element.deniedParticipations = res.body.deniedParticipations;
          element.acceptedParticipations = res.body.acceptedParticipations;
        }
      });
      
    });
  }

  loadSearchMatches(id:string){
    this.URideProvider.getSearchMatches(id, this.userProvider.getUserId()).subscribe(res => {
      this.mySearches.forEach((element) => {
        console.log(element);
        if(res && res.body && res.body.ID && element.ID == res.body.ID){
          element.recommendationsLifts = res.body.recommendationsLifts;
          element.participationRequests = res.body.participationRequests;
          element.requestedParticipations = res.body.requestedParticipations;
          element.quitParticipations = res.body.quitParticipations;
          element.deniedParticipations = res.body.deniedParticipations;
          element.acceptedparticipations = res.body.acceptedParticipations;
          element.canceledparticipations = res.body.canceledParticipations;
          return element;
        }
      });
      console.log(this.mySearches);
    });
  }



  requestSearchParticipation(idLift: string,idSearch: string){
    this.URideProvider.requestParticipation(idSearch, idLift, this.userProvider.getUserId()).subscribe(resp => {
        this.loadSearches();
        this.loadSearchMatches(idSearch);
    });
  }

  requestLiftParticipation(idSearch: string, idLift: string) {
    this.URideProvider.requestParticipation(idSearch, idLift, this.userProvider.getUserId()).subscribe(resp => {
      this.loadOffers();
      this.loadOfferMatches(idLift);
    }); 
  }
  
  requestLiftLiftParticipation(idUserLift: any, idLiftRecommendationAsLift: any){
    let liftUserId =  this.userProvider.getUserId();
       this.URideProvider.requestLiftLiftParticipation(liftUserId, idUserLift, idLiftRecommendationAsLift).subscribe(resp =>{
          this.loadOffers(); 
          this.loadOfferMatches(idUserLift);
       });
  }

  acceptParticipation(participationId:string){
    let userId = this.userProvider.getUserId();
    this.URideProvider.respondToParticipationRequest(participationId, userId,  this.participationRequestStates.accepted ).subscribe(resp=> {
        this.loadOffers();
        this.loadSearches();
    });
  }

  rejectParticipation(participationId:string){
    let userId = this.userProvider.getUserId();
    this.URideProvider.respondToParticipationRequest(participationId, userId,  this.participationRequestStates.denied ).subscribe(resp=> {
      this.loadOffers();
      this.loadSearches();
    });
  }

  quitSearchParticipation(participationId:string){
    let userId = this.userProvider.getUserId();
    this.URideProvider.respondToParticipationRequest(participationId, userId,  this.participationRequestStates.quit ).subscribe(resp=> {
      this.loadOffers();
      this.loadSearches();
    });
  }

  /**
   * Organisiere eine Fahrgemeinschaft
   */
  organizeCarPool() {
    this.carpoolEnabled = true;
  }

    // both modal methods for auth
    openLogin() {
        const loginModal = this.modalCtrl.create(LoginPage);
        loginModal.present().then(data => {
            console.log(data);
        }).catch(err => {
            console.log(err);
        });
    }
    openRegistration() {
        const regModal = this.modalCtrl.create(RegisterPage);
        regModal.present().then(data => {
            console.log(data);
        }).catch(err => {
            console.log(err);
        });
    }

}
