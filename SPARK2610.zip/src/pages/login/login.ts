import { Component } from '@angular/core';
import {IonicPage, LoadingController, NavParams, ToastController, ViewController} from 'ionic-angular';
import { UserProvider } from "../../providers/user/user";
import { Toast } from '@ionic-native/toast';

/**
 * Generated class for the LoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {

    userName: string;
    password: string;

    constructor(public viewCtrl: ViewController, public navParams: NavParams, public userProvider: UserProvider,
                public toast: Toast, public loadingCtrl: LoadingController) {
    }

    startLogin() {
        if (this.userName && this.password) {
            const loading = this.loadingCtrl.create({
                content: 'Anmelden...'
            });
            loading.present();

            this.userProvider.login({
                username: this.userName,
                password: this.password
            }).subscribe(data => {
                this.toast.show(data.msg,'3000','bottom').subscribe(() => {
                    if (data.msg === 'username and password correct') {
                        this.viewCtrl.dismiss();
                    }
                });
                loading.dismiss();
            }, err => {
                console.log(err);
                loading.dismiss();
            });
        }
    }
}
