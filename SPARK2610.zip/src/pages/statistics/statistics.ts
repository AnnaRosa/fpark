import {Component, ViewChild} from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {OrientationProvider} from "../../providers/orientation/orientation";
import { Chart } from 'chart.js';
import {DataHandlerProvider} from "../../providers/data-handler/data-handler";
import {SettingsProvider} from "../../providers/settings/settings"; // npm module import

@IonicPage()
@Component({
  selector: 'page-statistics',
  templateUrl: 'statistics.html',
})
export class StatisticsPage {

  @ViewChild('barOccCanvas') barOccCanvas;
  @ViewChild('doughnutOccCanvas') doughnutOccCanvas;

  barOccChart: any;
  doughnutOccChart: any;

  orientationSubscription: any;
  curOrientation: string = this.orientationProvider.getScreenOrientation();

  constructor(public navCtrl: NavController, public navParams: NavParams, public orientationProvider: OrientationProvider,
              public dataHandler: DataHandlerProvider, public settingsProvider: SettingsProvider) {
    this.orientationSubscription = this.orientationProvider.screenOrientationChanged.subscribe((o) => {
      this.curOrientation = o;
    })
  }

  /**
   * fired as soon as the page is manually refreshed  and on first page load
   * @param refresher
   */
  updateCharts(refresher?) {
    // get the parking lot sequel
    this.dataHandler.getAllParkingLots().then(data => {
      this.drawPieChartForOccupancy(data);
      this.drawBarChartsForOccupiedRows(data);
      if (refresher) {
        refresher.complete();
      }
    }, err => {
      console.log(err);
    });

  }

  drawPieChartForOccupancy(data) {
    // count the total occupancy
    const occupied = data.filter(object => object.state == 0);
    const occCount = occupied.length;
    const freeCount = data.length - occupied.length;

    // draw the pie / donut chart
    this.doughnutOccChart = new Chart(this.doughnutOccCanvas.nativeElement, {
      type: 'doughnut',
      data: {
        labels: ["Besetzt", "Frei"],
        datasets: [{
          label: 'Parkplatzbesetzung',
          data: [occCount, freeCount],
          backgroundColor: [
            '#e0e0e0',
            '#7cb342'
          ],
          hoverBackgroundColor: [
            "#e0e0e0",
            "#7cb342"
          ]
        }]
      }

    });
  }

  drawBarChartsForOccupiedRows(data) {
    // get each row dynamically
    let rowLabels = [];
    let rowData = {};
    for (let lot of data) {
      const row = lot.id.charAt(0);
      if (rowLabels.indexOf(row) === -1) {
        rowLabels.push(row);
      }
      if(!rowData[row]) {
        rowData[row] = [];
      }
      rowData[row].push(lot);
    }
    rowLabels.sort();

    // fill up the data for each row
    let datasets = [];
    let occArr = [];
    let freeArr = [];
    for(let label of rowLabels) {
      const occupied = rowData[label].filter(object => object.state == 0);
      const occCount = occupied.length;
      const freeCount = rowData[label].length - occupied.length;
      occArr.push(occCount);
      freeArr.push(freeCount);
    }

    // fill up the datasets
    datasets.push({
      label: 'Besetzt',
      data: occArr,
      backgroundColor: '#e0e0e0',
      hoverBackgroundColor: "#e0e0e0"
    });

    datasets.push({
      label: 'Frei',
      data: freeArr,
      backgroundColor: '#7cb342',
      hoverBackgroundColor: "#7cb342"
    });

    // draw the stacked bar chart
    this.barOccChart = new Chart(this.barOccCanvas.nativeElement, {
      type: 'bar',
      data: {
        labels: rowLabels,
        datasets: datasets
      },
      options: {
        scales: {
          yAxes: [{
            ticks: {
              beginAtZero:true
            },
            stacked: true
          }],
          xAxes: [{
            stacked: true
          }]
        }
      }
    });
  }

  ionViewDidLoad() {
    this.updateCharts();
  }
}
