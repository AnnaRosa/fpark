import {HttpClient, HttpHeaders} from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable()
export class UserProvider {

    private loginUrl: string = 'https://yvv3n1ykna.execute-api.eu-central-1.amazonaws.com/prod/user/login';
    private registerUrl: string = 'https://yvv3n1ykna.execute-api.eu-central-1.amazonaws.com/prod/user/register';
    private apiKey: string = 'Al4IQiM6kw5aTuRDX1FVf6TBeJojL5977G0qQpSL';
    private readonly awsHeaders: HttpHeaders;
    private uId: string; 

    private isAuthenticated: boolean = false;

    constructor(public http: HttpClient) {
        // TODO RESET UID WHEN LOGIN WORKS
        this.uId = 'TestUser';
        this.awsHeaders = new HttpHeaders({
            'x-api-key': this.apiKey,
            'Content-Type': 'application/json'
        });
    }

    /**
     * registers a new user
     */
    public register(userObject) {
        const req = this.http.post<any>(this.registerUrl, {
            username: userObject['username'], // [String]*
            password: userObject['password'], // [String]*
            fullname: userObject['fullname'], // [String]
            residence: userObject['residence'], //[String]
            email: userObject['email'], // [String]*,
            aboutMe: userObject['aboutMe'], // [String]
            numberPlate: userObject['numberPlate'], // [String]
            isPrivate: userObject['isPrivate'] // [Boolean]
        }, {
            headers: this.awsHeaders
        });
        req.subscribe(data => {
            if (data.hasOwnProperty('msg') && data['msg'] === 'registration successful') {
                this.isAuthenticated = true;
                this.uId = userObject['username']
            }
        });
        return req;
    }

    /**
     * login for an existing user
     */
    public login(userObject) {
        const req = this.http.post<any>(this.loginUrl, {
            username: userObject['username'], // [String]*
            password: userObject['password'] // [String]*
        }, {
            headers: this.awsHeaders
        });
        req.subscribe(data => {
            if (data.hasOwnProperty('msg') && data['msg'] === 'username and password correct') {
                this.isAuthenticated = true;
                this.uId = userObject['username'];
            }
        });
        return req;
    }

    public logout() {
        this.isAuthenticated = false;
    }

    public isLoggedIn() {
        return this.isAuthenticated;
    }
    public getHttpClient(){
        return this.http;
    }
    public getUserId(){
      return this.uId;
    }
}