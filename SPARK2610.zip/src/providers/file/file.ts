import { Injectable } from '@angular/core';
import { File } from "@ionic-native/file";
import { FilePath } from "@ionic-native/file-path";

@Injectable()
export class FileProvider {

  constructor(private file: File, private filePath: FilePath) { }

  /**
   * Löse File Uri auf dem Gerät auf
   * @param {string} fileUri
   * @returns {Promise<any>}
   */
  getFileEntry(fileUri: string) {
    return new Promise((resolve, reject) => {
      this.file.resolveLocalFilesystemUrl(fileUri).then((entry) => {
        resolve(entry);
      }, (fileErr) => {
        reject(fileErr);
      })
    });
  }

  /**
   * Holt den nativen Pfad auf dem Gerät für eine File URI
   * @param {string} fileUri
   * @returns {Promise<any>}
   */
  getNativePath(fileUri: string) {
    return new Promise((resolve, reject) => {
      this.filePath.resolveNativePath(fileUri).then((nativePath) => {
        resolve(nativePath);
      }, (pathErr) => {
        reject(pathErr);
      })
    });
  }
}
