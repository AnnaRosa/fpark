import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

/*
  Generated class for the GamificationProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class GamificationProvider {

  // dummy achievements
  achievements: object[] = [
    {name: "Parkplatzsuche", description: "Verwende einmal die komplette Parkplatzsuche", date: new Date()},
    {name: "Autosucher", description: "Finde dein Auto durch den Smartfinder", date: new Date()},
    {name: "Cäsar", description: "Gib dein Kurzfeedback zu einem Parkvorgang", date: new Date()},
  ];

  constructor(public http: HttpClient) {

  }

  setNewAchievement(name: string) {
    // TODO: Hole Achievement aus DB anhand Namen
    // this.achievements.push()
  }

  getAchievements() {
    return this.achievements;
  }

}
