import { Injectable } from '@angular/core';
import { LocalNotifications } from "@ionic-native/local-notifications";
import { Platform } from "ionic-angular";

@Injectable()
export class PushLocalProvider {

  constructor(private localNotification: LocalNotifications, private platform: Platform) {
    this.localNotification.requestPermission();
  }

  /**
   * Sendet eine lokale Notification, ohne dass ein Server verwendet werden muss
   * @param id
   * @param {string} title
   * @param text
   */
  scheduleNotification(id: number, title: string, text: string) {
    if(this.platform.is('cordova')) {
      this.localNotification.hasPermission().then(
        (permission) => {
          if (permission) {

            // Create the notification
            this.localNotification.schedule({
              title: title,
              text: text,
              id: id,
              icon: 'assets/icon/favicon.ico',
              led: '#8bc34a'
            });
          } else {
            this.localNotification.requestPermission()
          }
        }
      );
    }
  }

}
