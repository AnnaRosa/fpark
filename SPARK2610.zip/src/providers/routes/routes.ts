import {HttpClient} from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable()
export class RouteProvider {

    private apiIdHere: string = '9tOLjfx66fdKESJYR49H';
    private appCodeHere: string = 'yPtNbJLM3KTm68lV0NGWGQ';
    private universityLocation = 'geo!48.4797881,9.182772';

    constructor(public http: HttpClient) {
    }

    public getAddressFromCoordinates(loc: string) {
        const url = 'https://reverse.geocoder.api.here.com/6.2/reversegeocode.json';
        const addrreq=this.http.get<any>(url, {
          params: {
          app_code: this.appCodeHere,
          app_id: this.apiIdHere,
          prox: loc+',500',
          mode: 'retrieveAddresses',
          }
        });
        addrreq.subscribe(data => {
            console.log(data);
        });
        return addrreq;
    }

    public getCoordinatesFromAddress(address: string){
      const url = 'https://geocoder.api.here.com/6.2/geocode.json';
        const addrreq=this.http.get<any>(url, {
          params: {
           searchtext: address,
           app_id: this.apiIdHere,
           app_code: this.appCodeHere
          }
        });

        return addrreq;
    }

    public getRouteFromUniversity(loc:string){
        const url = 'https://route.api.here.com/routing/7.2/calculateroute.json';
        const addrreqRoute=this.http.get<any>(url, {
          params: {
          app_code: this.appCodeHere,
          app_id: this.apiIdHere,
          waypoint0: this.universityLocation,
          waypoint1: loc,
          mode: 'fastest;car;traffic:disabled'          
        }
        });
        return addrreqRoute;
    }

    public getRouteToUniversity(loc: string){
      const url = 'https://route.api.here.com/routing/7.2/calculateroute.json';
        const addrreqRoute=this.http.get<any>(url, {
          params: {
          app_code: this.appCodeHere,
          app_id: this.apiIdHere,
          waypoint0: loc,
          waypoint1: this.universityLocation,
          mode: 'fastest;car;traffic:disabled'
          }
        });
        return addrreqRoute;
    }

    public getAddressFromIncompleteAddress(incompleteAddress: string){ 
      const url = 'http://autocomplete.geocoder.api.here.com/6.2/suggest.json';
      const addrreq=this.http.get<any>(url, {
        params: {
        app_code: this.appCodeHere,
        app_id: this.apiIdHere,
        query: incompleteAddress,
        country: 'DEU',
        language: 'de' 
        }
      });
      return addrreq;
    }

}