import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {OverviewPage} from "../../pages/overview/overview";

declare let L: any;

enum ParkingLotStatus {
  UNKNOWN,
  FREE,
  OCOUPIED
}
/**
 * ParkingLot Object
 */
class ParkingLots {
  name: string;
  polygon: any;
  status: ParkingLotStatus;
  centerPoint: any;
  isHighlighted: boolean;
  constructor(name:string, polygon:any, centerPoint:any) {
    this.name = name;
    this.polygon = polygon;
    this.status = ParkingLotStatus.UNKNOWN;
    this.centerPoint = centerPoint;
    this.isHighlighted = false;
  }
  isFree() {
    return this.status === ParkingLotStatus.FREE;
  }
  updateStatusColor() {
    switch (this.status) {
      case ParkingLotStatus.OCOUPIED:
        this.polygon.setStyle({fillColor: '#f03'});
        this.polygon.setStyle({color: '#9B0000'});
        this.polygon.fillColor="#f03";
        this.polygon.color="#9B0000";
        break;
      case ParkingLotStatus.FREE:
        this.polygon.setStyle({fillColor: '#1e97e5'});
        this.polygon.fillColor="#1e97e5";
        if(this.isHighlighted) {
          this.polygon.setStyle({color: '#fc8f04'});
          this.polygon.color="#fc8f04";
          this.polygon.setStyle({fillColor: '#fc8f04'});
          this.polygon.fillColor="#fc8f04";
        } else {
          this.polygon.setStyle({color: '#245492'});
          this.polygon.color="#245492";
        }
        break;
      default:
        this.polygon.setStyle({fillColor: '#dddddb'});
        this.polygon.setStyle({color: '#6e6f69'});
        this.polygon.fillColor="#dddddb";
        this.polygon.color="#6e6f69";
    }
  }
}
@Injectable()
export class DataHandlerProvider {
  parkingLotApi: string = "https://81pjf2nlgi.execute-api.eu-central-1.amazonaws.com/test/parking/init/";
  constructor(public http: HttpClient) { }

  getParkingLotJSON(parkingLots) {
    try {
      return new Promise(resolve => {
          this.http.get<any>('assets/geo-data/parking.json').subscribe(data => {
            for (let parkingLot of data.features) {
              if (parkingLot.properties.amenity == "parking_space") {
                let polygon = L.polygon([
                  [parkingLot.geometry.coordinates[0][0][1], parkingLot.geometry.coordinates[0][0][0]],
                  [parkingLot.geometry.coordinates[0][1][1], parkingLot.geometry.coordinates[0][1][0]],
                  [parkingLot.geometry.coordinates[0][2][1], parkingLot.geometry.coordinates[0][2][0]],
                  [parkingLot.geometry.coordinates[0][3][1], parkingLot.geometry.coordinates[0][3][0]],
                ], {fillColor: '#dddddb', weight: 0.1, color: "#6e6f69", fillOpacity: 0.5}).addTo(OverviewPage.map);
                polygon.bindPopup(parkingLot.properties.name);
                const centerPoint = {lat: ((parkingLot.geometry.coordinates[0][0][1]+parkingLot.geometry.coordinates[0][2][1])/2), lng: ((parkingLot.geometry.coordinates[0][0][0]+parkingLot.geometry.coordinates[0][2][0])/2)};
                parkingLots.push(new ParkingLots(parkingLot.properties.name, polygon, centerPoint));
              }
            }
            this.updateParkingLots(parkingLots);
          });
      });
    } catch (err) {
      return new Promise(resolve => {});
    }
  }

  updateParkingLots(parkingLots) {
    try {
      return new Promise(resolve => {
        this.http.get<any>(this.parkingLotApi).subscribe(data => {
          for (let object of data.items) {
            for (let parkingLot of parkingLots) {
              if(object.id === parkingLot.name) {
                if(object.state == "1")
                  parkingLot.status = ParkingLotStatus.FREE;
                else
                  parkingLot.status = ParkingLotStatus.OCOUPIED;
                parkingLot.updateStatusColor();
                break;
              }
            }
          }
        });
      });
    } catch (err) {
        return new Promise(resolve => {});
    }
  }

  /**
   * returns all parking lots for visualization of statistics
   * @returns {Promise<any>}
   */
  getAllParkingLots() {
    return new Promise((resolve, reject) => {
      try {
        this.http.get<any>(this.parkingLotApi).subscribe(data => {
          if(data.items) {
            resolve(data.items);
          } else {
            reject(null);
          }
        });
      } catch(err) {
        reject(err);
      }
    });
  }
}
