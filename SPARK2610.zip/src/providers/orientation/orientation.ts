import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ScreenOrientation } from "@ionic-native/screen-orientation";
import {Subject} from "rxjs/Subject";


@Injectable()
export class OrientationProvider {
  screenOrientationChanged: Subject<string> = new Subject<string>();

  constructor(public http: HttpClient, private screenOrientation: ScreenOrientation) {
    this.screenOrientation.onChange().subscribe(() => {
      let roughScreenOrientation = this.screenOrientation.type.split('-')[0];
      this.screenOrientationChanged.next(roughScreenOrientation);
    });
  }

  /**
   * hole screen orientation
   * @returns {string}
   */
  getScreenOrientation() {
    return this.screenOrientation.type;
  }

  /**
   * setze und sperre screen orientation
   * @param {string} type
   */
  setScreenOrientation(type: string) {
    this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS[type]);
  }

  /**
   * setze screen orientation auf automatisch
   */
  unlockScreenRotation() {
    this.screenOrientation.unlock();
  }

}
