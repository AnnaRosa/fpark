import { HttpClient } from '@angular/common/http';
import {Injectable, NgZone} from '@angular/core';
import { BackgroundGeolocation } from '@ionic-native/background-geolocation';
import { Geolocation, Geoposition } from '@ionic-native/geolocation';
import 'rxjs/add/operator/filter';
import {ParkingProvider} from "../parking/parking";
import {BehaviorSubject} from "rxjs/BehaviorSubject";

/*
  Generated class for the LocationTrackerProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class LocationTrackerProvider {
  public watch: any;
  public lat: number = 0;
  public lng: number = 0;
  public dist: number = 0;
  public distChanged = new BehaviorSubject(this.dist);

  constructor(public http: HttpClient, public zone: NgZone, public backgroundGeolocation: BackgroundGeolocation, public geolocation: Geolocation, public parking: ParkingProvider) {
  }

  startTracking() {

    let config = {
      desiredAccuracy: 0,
      stationaryRadius: 20,
      distanceFilter: 10,
      debug: true,
      interval: 2000
    };

    this.backgroundGeolocation.configure(config).subscribe((location) => {

      console.log('BackgroundGeolocation:  ' + location.latitude + ',' + location.longitude);

      // Run update inside of Angular's zone
      this.zone.run(() => {
        this.lat = location.latitude;
        this.lng = location.longitude;
        this.dist = 0;
        this.distChanged.next(this.dist);
      });

    }, (err) => {

      console.log(err);

    });

    // Turn ON the background-geolocation system.
    this.backgroundGeolocation.start();


    // Foreground Tracking

    let options = {
      frequency: 3000,
      enableHighAccuracy: true
    };

    this.watch = this.geolocation.watchPosition(options).filter((p: any) => p.code === undefined).subscribe((position: Geoposition) => {

      // Run update inside of Angular's zone
      this.zone.run(() => {
        this.lat = position.coords.latitude;
        this.lng = position.coords.longitude;
        this.dist = 0;
        this.distChanged.next(this.dist);
      });

    });
  }

  stopTracking() {
    console.log('stopTracking');

    this.backgroundGeolocation.finish();
    this.watch.unsubscribe();
  }

  calculateDistance(lat1, lng1, lat2, lng2) {
    // für performance, nur wenn mehr als 1m bewegt
    let R = 6371e3;
    let phi_1 = this.degToRad(lat1);
    let phi_2 = this.degToRad(lat2);
    let delta_phi = this.degToRad(lat2-lat1);
    let delta_pi = this.degToRad(lng2-lng1);

    let a = Math.sin(delta_phi/2) * Math.sin(delta_phi/2) +
      Math.cos(phi_1) * Math.cos(phi_2) *
      Math.sin(delta_pi/2) * Math.sin(delta_pi/2);
    let c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

    return(R * c);
  }

  degToRad(rad: number) {
    return rad * (Math.PI / 180);
  }

}
