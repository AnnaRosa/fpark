import { Injectable } from '@angular/core';
import { PopoverSettingsPage } from "../../pages/popover-settings/popover-settings";
import { PopoverController } from "ionic-angular";

@Injectable()
export class SettingsProvider {

    constructor(public popoverCtrl: PopoverController) { }

    presentPopover(event) {
        let popover = this.popoverCtrl.create(PopoverSettingsPage);
        popover.present({
            ev: event
        });
    }
}
