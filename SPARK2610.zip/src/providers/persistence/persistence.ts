import { Injectable } from '@angular/core';
import { Storage } from "@ionic/storage";
import { Subject } from "rxjs/Subject";

@Injectable()
export class PersistenceProvider {

  profileImageUri: string = 'assets/imgs/profile/profile-placeholder.jpg';
  profileImageChanged: Subject<string> = new Subject<string>();

  // TODO: Datenbankverbindung

  constructor(private storage: Storage) {
    // Profilbild schon gesetzt
    this.storage.get('profileImg').then((result) => {
      if(result)
        this.profileImageUri = result;
    });
  }

  getFromStorage(key: string) {
    return new Promise((resolve, reject) => {
      this.storage.get(key).then(
        (value) => resolve(value),
        (err) => reject(err)
      );
    });
  }

  writeToStorage(key: string, value: any) {
    return new Promise((resolve, reject) => {
      this.storage.set(key, value).then(
        (result) => resolve(result),
        (err) => reject(err)
      );
    });
  }

  getProfileImageUri() {
    return this.profileImageUri;
  }

  setProfileImageUri(imageUri: string) {
    this.profileImageUri = imageUri;
    this.profileImageChanged.next(imageUri);
    this.writeToStorage('profileImg', imageUri);
  }

}
