import {HttpClient} from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable()
export class URideProvider {
    constructor(public http: HttpClient) {
    }

    public getSearches(uId: string){
        const urlTry = 'https://cyxg0opu60.execute-api.eu-central-1.amazonaws.com/URide/mysearches/';
        const crequest = this.http.get<any>(urlTry, {params: {contentType: 'application/json', uId: uId}});
        return crequest; 
      }
  
      public getOffers(uId: string){
        const urlTry = 'https://cyxg0opu60.execute-api.eu-central-1.amazonaws.com/URide/myoffers/';
        const crequest = this.http.get<any>(urlTry, {params: {contentType: 'application/json', uId: uId}});
        return crequest;
      }
      
      public getOpenRequests(uId: string){
        const urlTry = 'https://cyxg0opu60.execute-api.eu-central-1.amazonaws.com/URide/openrequests/';
        const crequest = this.http.get<any>(urlTry, {params: {contentType: 'application/json', uId: uId}});
        return crequest; 
      }
   
      public addSearch(uId:string, directionToUniversity: boolean, liftTime: any, addressName: string, address: string, waypoints: any){
        console.log(uId);
        let body= {
          uId: uId,
          directionToUniversity: directionToUniversity?1:0,
          startDate: liftTime,
          route: {
            name: addressName,
            address: address, 
            orderedWaypoints: waypoints, 
          }
        };
        const urlTry = 'https://cyxg0opu60.execute-api.eu-central-1.amazonaws.com/URide/mysearches';
        const crequest = this.http.post<any>(urlTry, JSON.stringify(body), {params: {contentType: 'application/json'}});
        return crequest; 
      }

      public addSearchWithExistingRoute (uId:string, liftTime: any, routeId: number){
        let body= {
          uId: uId, 
          startDate: liftTime,
          routeId: routeId
        };
        const urlTry = 'https://cyxg0opu60.execute-api.eu-central-1.amazonaws.com/URide/mysearches/addsearchwithexistingroute';
        const crequest = this.http.post<any>(urlTry, JSON.stringify(body), {params: {contentType: 'application/json'}});
        return crequest; 
      }
  
      public addOffer (uId:string, directionToUniversity: boolean, liftTime: any, addressName: string, address: string, waypoints: any,
        freeSeats: number){
          console.log(uId);
        let body= {
          uId: uId, 
          directionToUniversity: directionToUniversity?1:0,
          startDate: liftTime,
          openSeats: freeSeats,
          route: {
            name: addressName,
            address: address, 
            orderedWaypoints: waypoints,
          }
        };
        const urlTry = 'https://cyxg0opu60.execute-api.eu-central-1.amazonaws.com/URide/myoffers';
        const crequest = this.http.post<any>(urlTry, JSON.stringify(body), {params: {contentType: 'application/json'}});
        return crequest; 
      }

      public addOfferWithExistingRoute (uId:string, liftTime: any, routeId: number, freeSeats: number){
        let body= {
          uId: uId, 
          startDate: liftTime,
          openSeats: freeSeats,
          routeId: routeId
        };
        const urlTry = 'https://cyxg0opu60.execute-api.eu-central-1.amazonaws.com/URide/myoffers/addofferwithexistingroute';
        const crequest = this.http.post<any>(urlTry, JSON.stringify(body), {params: {contentType: 'application/json'}});
        return crequest; 
      }  
  
      public requestParticipation(idSearch: string, idLift: string,  userId: string){
        console.log('requiii');
        let body ={
          uId: userId,
          liftId: idLift, 
          searchId: idSearch,
          requestedBy: 'liftSeeker',
        }
        const urlTry = 'https://cyxg0opu60.execute-api.eu-central-1.amazonaws.com/URide/requestparticipation'; 
        const crequest = this.http.post<any>(urlTry, JSON.stringify(body), {params: {contentType: 'application/json'}});
        return crequest;
      }

      public requestLiftLiftParticipation(uId: string, idSearchLift: string,  idLiftLift: string){
        let body ={
          uId: uId,
          userLiftId: idSearchLift, 
          liftRecommendationAsLiftId: idLiftLift,
        }
        const urlTry = 'https://cyxg0opu60.execute-api.eu-central-1.amazonaws.com/URide/requestliftliftparticipation'; 
        const crequest = this.http.post<any>(urlTry, JSON.stringify(body), {params: {contentType: 'application/json'}});
        return crequest;
      }

      public respondToParticipationRequest(participationId: string, uId: string, responseState: string){
          let body = {
            respondingUserId: uId,
            participationId: participationId,
            newParticipationState: responseState 
          };
        const urlTry = 'https://cyxg0opu60.execute-api.eu-central-1.amazonaws.com/URide/changerequestparticipationstate';
        const crequest = this.http.post<any>(urlTry, JSON.stringify(body), {params: {contentType: 'application/json'}});
        return crequest;
      }
      
      public getSearchMatches(searchId: string, userId: string){
        const urlTry = 'https://cyxg0opu60.execute-api.eu-central-1.amazonaws.com/URide/searchmatches';
        const crequest = this.http.get<any>(urlTry, {params: {id: searchId, uId: userId}});
        return crequest;
      } 

      public getOfferMatches(offerId: string, userId: string){
        const urlTry = 'https://cyxg0opu60.execute-api.eu-central-1.amazonaws.com/URide/offermatches';
        const crequest = this.http.get<any>(urlTry, {params: {id: offerId, uId: userId}});
        return crequest;
      } 

      public getUserRoutes(userId: string){
        const urlTry = 'https://cyxg0opu60.execute-api.eu-central-1.amazonaws.com/URide/userroutes';
        const crequest = this.http.get<any>(urlTry, {params: {uId: userId}});
        return crequest;
      } 
}