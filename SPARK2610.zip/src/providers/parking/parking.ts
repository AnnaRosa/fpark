import { Injectable } from '@angular/core';
import {DataHandlerProvider} from "../../providers/data-handler/data-handler";

import "leaflet";
import "leaflet-tilelayer-mbtiles-ts";

@Injectable()
export class ParkingProvider {
  parkingLots: any[] = [];

  private parkingLotCoordinates = {
    lng: 9.1882144,
    lat: 48.4803986
  };

  /**
   * Load parking
   */
  constructor(public dataHandlerProvider: DataHandlerProvider) {
    this.dataHandlerProvider.getParkingLotJSON(this.parkingLots);
  }

  distanceToParkingLog(currentLocation) {
    return this.calculateDistance(this.parkingLotCoordinates.lat,this.parkingLotCoordinates.lng,currentLocation.lat,currentLocation.lng);
  }

  getParkingLotCoordinates() {
    return this.parkingLotCoordinates;
  }

  runParkingLotUpdateRoutine () {
    this.dataHandlerProvider.updateParkingLots(this.parkingLots).then();
  }

  public removeHighlight() {
    for(let parkingLot of this.parkingLots) {
      if(parkingLot.isHighlighted) {
        parkingLot.isHighlighted = false;
        parkingLot.updateStatusColor();
        break;
      }
    }
  }

  public checkNearestParkingLot(isTracking, currentLocation) {
    if(isTracking) {
      let tmpDistance = 0;
      let minDistance = 99999999999999;
      let nearestParkingLot = null;
      for(let parkingLot of this.parkingLots) {
        if(parkingLot.isFree()) {
          if(parkingLot.isHighlighted) {
            parkingLot.isHighlighted = false;
            parkingLot.updateStatusColor();
          }
          tmpDistance = this.calculateDistance(parkingLot.centerPoint.lat,parkingLot.centerPoint.lng,currentLocation.lat,currentLocation.lng);
          if(tmpDistance<minDistance) {
            minDistance = tmpDistance;
            nearestParkingLot = parkingLot;
          }
        }
      }
      if(nearestParkingLot !== null) {
        nearestParkingLot.isHighlighted = true;
        nearestParkingLot.updateStatusColor();
        this.parkingLotCoordinates.lat = nearestParkingLot.centerPoint.lat;
        this.parkingLotCoordinates.lng = nearestParkingLot.centerPoint.lng;
      } else {
        this.parkingLotCoordinates.lat = 48.4803986;
        this.parkingLotCoordinates.lng = 9.1882144;
      }
    }
  }

  calculateDistance(lat1, lng1, lat2, lng2) {
    // für performance, nur wenn mehr als 1m bewegt
    let R = 6371e3;
    let phi_1 = this.degToRad(lat1);
    let phi_2 = this.degToRad(lat2);
    let delta_phi = this.degToRad(lat2-lat1);
    let delta_pi = this.degToRad(lng2-lng1);
    let a = Math.sin(delta_phi/2) * Math.sin(delta_phi/2) +
      Math.cos(phi_1) * Math.cos(phi_2) *
      Math.sin(delta_pi/2) * Math.sin(delta_pi/2);
    let c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return(R * c);
  }
  degToRad(rad: number) {
    return rad * (Math.PI / 180);
  }
}

