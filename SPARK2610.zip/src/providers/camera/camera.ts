import { Injectable } from '@angular/core';
import { Camera, CameraOptions } from "@ionic-native/camera";
import { Base64ToGallery } from "@ionic-native/base64-to-gallery";
import { FileProvider } from "../file/file";
import { Crop } from "@ionic-native/crop";

@Injectable()
export class CameraProvider {

  constructor(private camera: Camera, private base64ToGallery: Base64ToGallery, private fileProvider: FileProvider,
              private crop: Crop) { }

  /**
   * Hole / Schieße Bild von [source] des Geräts
   * @param {string} source - 'CAMERA', 'PHOTOLIBRARY', 'SAVEDPHOTOALBUM'
   * @returns {Promise<any>}
   */
  getImage(source: string) {
    const camOptions: CameraOptions = {
      quality: 80,
      sourceType: this.camera.PictureSourceType[source],
      destinationType: this.camera.DestinationType.NATIVE_URI,
      encodingType: this.camera.EncodingType.JPEG,
      mediaType: this.camera.MediaType.PICTURE
    };
    return new Promise((resolve, reject) => {
      this.camera.getPicture(camOptions).then((fileUri) => {
        this.fileProvider.getNativePath(fileUri).then((nativeUri) => {
          this.camera.cleanup();
          resolve(nativeUri);
        }, (fileErr) => {
          this.camera.cleanup();
          reject(fileErr);
        });
      }, (err) => {
        this.camera.cleanup();
        reject(err);
      });
    });
  }

  /**
   * Schneidet ein vorhandenes Bild zu und liefert die neue URI zurück
   * @param {string} imageUri
   * @returns {Promise<any>}
   */
  cropImage(imageUri: string) {
    return new Promise((resolve, reject) => {
      this.crop.crop(imageUri, {quality: 75})
        .then(
          newPath => resolve(newPath),
          error => reject(error)
        );
    });
  }
}
